package com.hezpor.mousetool

import android.content.Context
import android.graphics.Canvas
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.view.InputDevice
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import kotlin.math.max

/** Khung test chuột: đo Hz trong app + xem bộ lọc hoạt động (trắng = thô, cyan = đã lọc). */
class PadView(ctx: Context) : View(ctx) {
    var onHz: ((Int) -> Unit)? = null

    private var tuning = Tuning.load(ctx)
    private val filter = MouseFilter(tuning)
    private val meter = HzMeter()
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var rx = 0f
    private var ry = 0f
    private var fx = 0f
    private var fy = 0f
    private var lastX = Float.NaN
    private var lastY = Float.NaN
    private var ready = false
    private val trail = ArrayList<FloatArray>()
    private val d = resources.displayMetrics.density

    init {
        isFocusable = true
        isFocusableInTouchMode = true
        isClickable = true
        setOnCapturedPointerListener { _, e -> onCaptured(e); true }
    }

    fun reload() {
        tuning = Tuning.load(context)
        filter.t = tuning
        filter.reset()
    }

    fun clearAll() {
        meter.clear(); filter.reset(); trail.clear(); ready = false; invalidate()
    }

    private fun ensureInit() {
        if (!ready) {
            rx = width / 2f; ry = height / 2f; fx = rx; fy = ry; ready = true
        }
    }

    private fun onCaptured(e: MotionEvent) {
        if (e.actionMasked == MotionEvent.ACTION_BUTTON_PRESS &&
            e.actionButton == MotionEvent.BUTTON_SECONDARY
        ) {
            releasePointerCapture()
            invalidate()
            return
        }
        if (e.actionMasked == MotionEvent.ACTION_MOVE) feed(e, true)
    }

    private fun feed(e: MotionEvent, rel: Boolean) {
        ensureInit()
        val n = e.historySize
        for (i in 0..n) {
            val t = if (i < n) e.getHistoricalEventTime(i) else e.eventTime
            val x = if (i < n) e.getHistoricalX(i) else e.x
            val y = if (i < n) e.getHistoricalY(i) else e.y
            step(x, y, t.toDouble(), rel)
        }
        onHz?.invoke(meter.hz())
        invalidate()
    }

    private fun step(x: Float, y: Float, t: Double, rel: Boolean) {
        val dx: Float
        val dy: Float
        if (rel) {
            dx = x; dy = y
        } else {
            dx = if (lastX.isNaN()) 0f else x - lastX
            dy = if (lastY.isNaN()) 0f else y - lastY
            lastX = x; lastY = y
        }
        meter.add(t)
        val o = filter.apply(dx, dy, t)
        rx = (rx + dx).coerceIn(0f, width.toFloat())
        ry = (ry + dy).coerceIn(0f, height.toFloat())
        fx = (fx + o[0]).coerceIn(0f, width.toFloat())
        fy = (fy + o[1]).coerceIn(0f, height.toFloat())
        trail.add(floatArrayOf(fx, fy))
        if (trail.size > 80) trail.removeAt(0)
    }

    override fun onGenericMotionEvent(event: MotionEvent): Boolean {
        if (event.isFromSource(InputDevice.SOURCE_MOUSE)) {
            when (event.actionMasked) {
                MotionEvent.ACTION_HOVER_MOVE -> { feed(event, false); return true }
                MotionEvent.ACTION_HOVER_ENTER, MotionEvent.ACTION_HOVER_EXIT -> {
                    lastX = Float.NaN; lastY = Float.NaN
                }
            }
        }
        return super.onGenericMotionEvent(event)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (event.isFromSource(InputDevice.SOURCE_MOUSE)) {
            if (event.actionMasked == MotionEvent.ACTION_DOWN && !hasPointerCapture()) {
                requestFocus()
                requestPointerCapture()
                invalidate()
            } else if (event.actionMasked == MotionEvent.ACTION_MOVE) {
                feed(event, false)
            }
        }
        return true
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent): Boolean {
        if (hasPointerCapture() && (keyCode == KeyEvent.KEYCODE_ESCAPE || keyCode == KeyEvent.KEYCODE_BACK)) {
            releasePointerCapture()
            invalidate()
            return true
        }
        return super.onKeyDown(keyCode, event)
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        paint.style = Paint.Style.FILL
        paint.color = 0xFF0B141B.toInt()
        c.drawRoundRect(RectF(0f, 0f, w, h), 16 * d, 16 * d, paint)
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 1 * d
        paint.color = 0x5500E5FF
        c.drawRoundRect(RectF(0f, 0f, w, h), 16 * d, 16 * d, paint)

        if (trail.size > 1) {
            paint.strokeWidth = 2 * d
            for (i in 1 until trail.size) {
                paint.color = ((i * 255 / trail.size) shl 24) or 0x0000E5FF
                c.drawLine(trail[i - 1][0], trail[i - 1][1], trail[i][0], trail[i][1], paint)
            }
        }
        paint.style = Paint.Style.FILL
        if (ready) {
            paint.color = 0xFFFFFFFF.toInt()
            c.drawCircle(rx, ry, 4 * d, paint)
            paint.color = 0xFF00E5FF.toInt()
            c.drawCircle(fx, fy, 5 * d, paint)
        }
        paint.color = 0xFF9AA7B0.toInt()
        paint.textSize = 12 * d
        val msg = if (hasPointerCapture()) "Đang bắt chuột — chuột phải / Esc để thoát"
        else "Rê chuột vào đây, hoặc click để bắt chuột (đo thô)"
        c.drawText(msg, 12 * d, h - 12 * d, paint)
    }
}

/** Đồ thị đường cong gain theo vận tốc (giống đồ thị trong ảnh Tracking Control). */
class CurveView(ctx: Context) : View(ctx) {
    var tuning: Tuning = Tuning.load(ctx)
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val d = resources.displayMetrics.density

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        paint.style = Paint.Style.FILL
        paint.color = 0xFF0B141B.toInt()
        c.drawRoundRect(RectF(0f, 0f, w, h), 12 * d, 12 * d, paint)

        val l = 12 * d
        val r = w - 12 * d
        val t = 12 * d
        val b = h - 12 * d
        val maxV = 40f
        val yMin = 0.8f
        val yMax = max(1.6f, tuning.accelCap + 0.3f)

        fun px(v: Float) = l + (r - l) * (v / maxV)
        fun py(g: Float) = b - (b - t) * ((g - yMin) / (yMax - yMin))

        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 1 * d
        paint.color = 0x44FFFFFF
        c.drawLine(l, b, r, b, paint)
        c.drawLine(l, t, l, b, paint)

        paint.pathEffect = DashPathEffect(floatArrayOf(6 * d, 6 * d), 0f)
        c.drawLine(l, py(1f), r, py(1f), paint)
        paint.pathEffect = null

        val path = Path()
        var first = true
        var v = 0f
        while (v <= maxV) {
            val x = px(v)
            val y = py(tuning.gain(v) * 1f)
            if (first) { path.moveTo(x, y); first = false } else path.lineTo(x, y)
            v += 0.5f
        }
        paint.strokeWidth = 3 * d
        paint.color = 0xFF00E5FF.toInt()
        c.drawPath(path, paint)
    }
}
