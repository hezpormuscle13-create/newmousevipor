package com.hezpor.mousetool

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Outline
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.WindowManager
import android.widget.Button
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import android.widget.VideoView
import rikka.shizuku.Shizuku
import java.util.Locale
import kotlin.math.max
import kotlin.math.roundToInt

class MainActivity : Activity() {

    private val ACC = 0xFF00E5FF.toInt()
    private val TXT = 0xFFE8EEF2.toInt()
    private val DIM = 0xFF9AA7B0.toInt()
    private val OK = 0xFF3DDC84.toInt()
    private val BAD = 0xFFFF5A5F.toInt()

    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

    private val ui = Handler(Looper.getMainLooper())
    private var video: VideoView? = null
    private var player: MediaPlayer? = null

    private lateinit var pad: PadView
    private lateinit var curve: CurveView
    private lateinit var tvHz: TextView
    private lateinit var tvHzSys: TextView
    private lateinit var tvStats: TextView
    private lateinit var tvMap: TextView
    private lateinit var svcSwitch: Switch
    private lateinit var speedSl: Sl
    private val statusViews = LinkedHashMap<String, TextView>()

    private var hzMax = 0
    private var hzSum = 0L
    private var hzCnt = 0

    private val permListener = Shizuku.OnRequestPermissionResultListener { _, _ ->
        ui.post { refreshStatus() }
    }
    private val binderListener = Shizuku.OnBinderReceivedListener { ui.post { refreshStatus() } }
    private val deadListener = Shizuku.OnBinderDeadListener { ui.post { refreshStatus() } }

    private val ticker = object : Runnable {
        override fun run() {
            refreshStatus()
            val fresh = System.currentTimeMillis() - LiveState.sysHzTime < 1500
            tvHzSys.text = if (fresh) "Toàn hệ thống: ${LiveState.sysHz} Hz  (${LiveState.sysDev})"
            else if (!ShizukuHelper.granted()) "Toàn hệ thống: cần Shizuku (bật quyền bên dưới)"
            else if (!LiveState.monitorRunning) "Toàn hệ thống: bật công tắc 'Đo Hz toàn hệ thống' + Dịch vụ nền"
            else "Toàn hệ thống: -- (hãy di chuyển chuột)"
            val on = Prefs.getBool(this@MainActivity, K.SERVICE_ON, false)
            if (svcSwitch.isChecked != on) svcSwitch.isChecked = on
            ui.postDelayed(this, 500)
        }
    }

    // ---------------- helpers ----------------

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun roundBg(color: Int, radiusDp: Int, stroke: Int = 0): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(color)
        g.cornerRadius = dp(radiusDp).toFloat()
        if (stroke != 0) g.setStroke(dp(1), stroke)
        return g
    }

    private fun lp(top: Int = 0): LinearLayout.LayoutParams {
        val p = LinearLayout.LayoutParams(MATCH, WRAP)
        p.topMargin = dp(top)
        return p
    }

    private fun text(parent: LinearLayout, s: String, size: Float, color: Int, bold: Boolean = false, top: Int = 0): TextView {
        val t = TextView(this)
        t.text = s
        t.textSize = size
        t.setTextColor(color)
        if (bold) t.typeface = Typeface.DEFAULT_BOLD
        parent.addView(t, lp(top))
        return t
    }

    private fun card(parent: LinearLayout, title: String): LinearLayout {
        val l = LinearLayout(this)
        l.orientation = LinearLayout.VERTICAL
        l.setPadding(dp(16), dp(14), dp(16), dp(16))
        l.background = roundBg(0xB3101820.toInt(), 20, 0x33FFFFFF)
        parent.addView(l, lp(12))
        text(l, title, 16f, ACC, true)
        return l
    }

    private fun button(parent: LinearLayout, label: String, top: Int = 8, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = label
        b.isAllCaps = false
        b.setTextColor(Color.BLACK)
        b.background = roundBg(ACC, 12)
        b.setOnClickListener { onClick() }
        parent.addView(b, lp(top))
        return b
    }

    private fun switchRow(
        parent: LinearLayout, label: String, key: String, def: Boolean,
        onChange: ((Boolean) -> Unit)? = null
    ): Switch {
        val s = Switch(this)
        s.text = label
        s.setTextColor(TXT)
        s.textSize = 14f
        s.isChecked = Prefs.getBool(this, key, def)
        s.setOnCheckedChangeListener { _, v ->
            Prefs.setBool(this, key, v)
            onChange?.invoke(v)
        }
        parent.addView(s, lp(8))
        return s
    }

    private inner class Sl(val sb: SeekBar, val min: Float, val step: Float, val show: (Float) -> Unit) {
        fun set(v: Float) {
            sb.progress = ((v - min) / step).roundToInt()
            show(v)
        }
    }

    private fun slider(
        parent: LinearLayout, label: String, key: String,
        min: Float, max: Float, step: Float, def: Float, fmt: String,
        onChange: (Float) -> Unit = {}
    ): Sl {
        val steps = ((max - min) / step).roundToInt()
        val cur = Prefs.getFloat(this, key, def)
        val tv = text(parent, "", 13f, TXT, false, 10)
        val show: (Float) -> Unit = { v -> tv.text = label + ": " + String.format(Locale.US, fmt, v) }
        show(cur)
        val sb = SeekBar(this)
        sb.max = steps
        sb.progress = ((cur - min) / step).roundToInt()
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                val v = min + p * step
                show(v)
                if (fromUser) {
                    Prefs.setFloat(this@MainActivity, key, v)
                    onChange(v)
                }
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        parent.addView(sb, lp(0))
        return Sl(sb, min, step, show)
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    // ---------------- lifecycle ----------------

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS)
        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.TRANSPARENT
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility =
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN

        val root = FrameLayout(this)
        root.setBackgroundColor(Color.BLACK)

        val vv = VideoView(this)
        video = vv
        root.addView(vv, FrameLayout.LayoutParams(MATCH, MATCH))
        try {
            vv.setVideoURI(Uri.parse("android.resource://$packageName/${R.raw.bg_video}"))
            vv.setOnPreparedListener { m ->
                player = m
                m.isLooping = true
                applyVolume()
            }
            vv.setOnErrorListener { _, _, _ -> true }
            vv.start()
        } catch (e: Throwable) { }

        val scrim = View(this)
        scrim.setBackgroundColor(0x99000A12.toInt())
        root.addView(scrim, FrameLayout.LayoutParams(MATCH, MATCH))

        val scroll = ScrollView(this)
        scroll.isFillViewport = false
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(14), dp(52), dp(14), dp(40))
        scroll.addView(col, FrameLayout.LayoutParams(MATCH, WRAP))
        root.addView(scroll, FrameLayout.LayoutParams(MATCH, MATCH))
        setContentView(root)

        buildHeader(col)
        buildServiceCard(col)
        buildPermissionCard(col)
        buildHzCard(col)
        buildSpeedCard(col)
        buildTuningCard(col)
        buildSystemCard(col)
        buildNotesCard(col)

        try {
            Shizuku.addRequestPermissionResultListener(permListener)
            Shizuku.addBinderReceivedListenerSticky(binderListener)
            Shizuku.addBinderDeadListener(deadListener)
        } catch (e: Throwable) { }

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 7)
        }
    }

    override fun onResume() {
        super.onResume()
        try { video?.start() } catch (e: Throwable) { }
        ui.removeCallbacks(ticker)
        ui.post(ticker)
    }

    override fun onPause() {
        super.onPause()
        ui.removeCallbacks(ticker)
        try { video?.pause() } catch (e: Throwable) { }
    }

    override fun onDestroy() {
        try {
            Shizuku.removeRequestPermissionResultListener(permListener)
            Shizuku.removeBinderReceivedListener(binderListener)
            Shizuku.removeBinderDeadListener(deadListener)
        } catch (e: Throwable) { }
        try { video?.stopPlayback() } catch (e: Throwable) { }
        super.onDestroy()
    }

    private fun applyVolume() {
        val v = if (Prefs.getBool(this, K.SOUND_ON, true)) 1f else 0f
        try { player?.setVolume(v, v) } catch (e: Throwable) { }
    }

    // ---------------- UI sections ----------------

    private fun buildHeader(col: LinearLayout) {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        val img = ImageView(this)
        img.setImageResource(R.drawable.avatar)
        img.scaleType = ImageView.ScaleType.CENTER_CROP
        img.clipToOutline = true
        img.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(v: View, o: Outline) { o.setOval(0, 0, v.width, v.height) }
        }
        row.addView(img, LinearLayout.LayoutParams(dp(72), dp(72)))
        val tcol = LinearLayout(this)
        tcol.orientation = LinearLayout.VERTICAL
        tcol.setPadding(dp(14), 0, 0, 0)
        text(tcol, "Hezpor Mouse", 24f, Color.WHITE, true)
        text(tcol, "Đo Hz • Tốc độ chuột • Chạy nền", 12f, DIM)
        row.addView(tcol, LinearLayout.LayoutParams(0, WRAP, 1f))
        col.addView(row, lp())
    }

    private fun buildServiceCard(col: LinearLayout) {
        val c = card(col, "DỊCH VỤ NỀN (chạy khi thoát app)")
        svcSwitch = switchRow(c, "Bật dịch vụ nền (Foreground Service)", K.SERVICE_ON, false) { on ->
            if (on) MouseService.start(this) else MouseService.stop(this)
        }
        switchRow(c, "Tự chạy lại sau khi khởi động máy", K.BOOT_ON, true)
        switchRow(c, "Giữ CPU thức (WakeLock) – ổn định hơn, tốn pin hơn", K.WAKE_ON, true)
        switchRow(c, "Âm thanh video nền", K.SOUND_ON, true) { applyVolume() }
    }

    private fun buildPermissionCard(col: LinearLayout) {
        val c = card(col, "QUYỀN")
        for ((k, _) in listOf(
            "shizuku" to "Shizuku", "overlay" to "Lớp phủ", "write" to "Ghi cài đặt hệ thống",
            "secure" to "WRITE_SECURE_SETTINGS", "notif" to "Thông báo", "battery" to "Bỏ tối ưu pin",
            "service" to "Dịch vụ nền"
        )) {
            statusViews[k] = text(c, "", 13f, TXT, false, 4)
        }
        button(c, "1. Cấp quyền Shizuku / mở Shizuku") {
            if (!ShizukuHelper.available()) {
                val i = packageManager.getLaunchIntentForPackage("moe.shizuku.privileged.api")
                if (i != null) startActivity(i) else toast("Chưa cài Shizuku hoặc Shizuku chưa chạy. Cài Shizuku rồi Start.")
            } else if (!ShizukuHelper.granted()) {
                ShizukuHelper.request(100)
            } else toast("Đã có quyền Shizuku")
        }
        button(c, "2. Cấp TẤT CẢ quyền còn lại bằng Shizuku (1 chạm)") { grantAll() }
        button(c, "Lớp phủ (Hiển thị trên ứng dụng khác)") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        button(c, "Ghi cài đặt hệ thống") {
            startActivity(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:$packageName")))
        }
        button(c, "Thông báo") {
            if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 7)
            else startActivity(Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, packageName))
        }
        button(c, "Bỏ tối ưu pin (chạy nền ổn định)") {
            try {
                startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
            } catch (e: Throwable) {
                startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            }
        }
        button(c, "Cài đặt ứng dụng (Tự khởi động / chạy nền cho Xiaomi, Oppo, Vivo…)") {
            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
        }
    }

    private fun buildHzCard(col: LinearLayout) {
        val c = card(col, "ĐO HZ CHUỘT")
        tvHz = text(c, "-- Hz", 44f, ACC, true, 6)
        tvStats = text(c, "Max: -- | Trung bình: --", 13f, DIM)
        tvHzSys = text(c, "Toàn hệ thống: --", 13f, TXT, false, 6)

        pad = PadView(this)
        c.addView(pad, LinearLayout.LayoutParams(MATCH, dp(190)).apply { topMargin = dp(10) })
        pad.onHz = { hz ->
            if (hz > 0) {
                hzMax = max(hzMax, hz)
                hzSum += hz
                hzCnt++
                tvHz.text = "$hz Hz"
                tvStats.text = "Max: $hzMax Hz | Trung bình: ${hzSum / hzCnt} Hz"
            }
        }
        button(c, "Reset thống kê") {
            hzMax = 0; hzSum = 0; hzCnt = 0
            tvHz.text = "-- Hz"; tvStats.text = "Max: -- | Trung bình: --"
            pad.clearAll()
        }
        switchRow(c, "Đo Hz TOÀN HỆ THỐNG ngoài app (Shizuku)", K.SYS_HZ_ON, false) {
            if (it && !ShizukuHelper.granted()) toast("Cần cấp quyền Shizuku trước")
            if (it) ensureService()
        }
        switchRow(c, "Hiện Hz nổi (HUD) trên mọi ứng dụng", K.HUD_ON, false) {
            if (it && !Settings.canDrawOverlays(this)) {
                toast("Cần cấp quyền Lớp phủ")
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            }
            if (it) ensureService()
        }
        text(c, "Khung test đo thô theo thời gian sự kiện Android. Đo toàn hệ thống đọc trực tiếp /dev/input (micro giây) nên chính xác hơn.", 11f, DIM, false, 6)
    }

    private fun buildSpeedCard(col: LinearLayout) {
        val c = card(col, "TỐC ĐỘ CON TRỎ CHUỘT (hệ thống)")
        val cur = Sys.getPointerSpeed(this)
        if (!Prefs.sp(this).contains(K.SPEED_VAL)) Prefs.setFloat(this, K.SPEED_VAL, cur.toFloat())
        speedSl = slider(c, "Tốc độ", K.SPEED_VAL, -7f, 7f, 1f, cur.toFloat(), "%.0f") { v ->
            applySpeed(v.roundToInt())
        }
        text(c, "Dải -7 … +7 (0 = mặc định). Giá trị được ghi thẳng vào cài đặt hệ thống nên vẫn giữ nguyên sau khi thoát app.", 11f, DIM, false, 6)
        button(c, "Áp dụng lại ngay") { applySpeed(Prefs.getFloat(this, K.SPEED_VAL, 0f).roundToInt()) }
        button(c, "Về mặc định (0)") {
            Prefs.setFloat(this, K.SPEED_VAL, 0f); speedSl.set(0f); applySpeed(0)
        }
        switchRow(c, "KHÓA tốc độ (dịch vụ nền tự đặt lại nếu bị đổi)", K.SPEED_LOCK, false) {
            if (it) { ensureService(); applySpeed(Prefs.getFloat(this, K.SPEED_VAL, 0f).roundToInt()) }
        }
    }

    private fun applySpeed(v: Int) {
        Thread {
            val ok = Sys.setPointerSpeed(this, v)
            ui.post { if (!ok) toast("Không ghi được. Cấp 'Ghi cài đặt hệ thống' hoặc Shizuku.") }
        }.start()
    }

    private fun onTuningChanged() {
        pad.reload()
        curve.tuning = Tuning.load(this)
        curve.invalidate()
        val t = Tuning.load(this)
        tvMap.text = "→ Tốc độ hệ thống tương đương: ${t.systemSpeed()}  (DPI ${t.refDpi.roundToInt()}/${t.curDpi.roundToInt()}, gain×${String.format(Locale.US, "%.2f", t.gain(20f))})"
    }

    private fun buildTuningCard(col: LinearLayout) {
        val c = card(col, "TRACKING CONTROL")
        curve = CurveView(this)
        c.addView(curve, LinearLayout.LayoutParams(MATCH, dp(130)).apply { topMargin = dp(10) })
        tvMap = text(c, "", 12f, TXT, false, 8)

        val f = { _: Float -> onTuningChanged() }
        text(c, "CORE TUNING", 13f, ACC, true, 12)
        slider(c, "EMA Fast (ms)", K.EMA, 0.5f, 20f, 0.5f, 2f, "%.1f", f)
        slider(c, "Velocity Window", K.VELWIN, 1f, 16f, 1f, 4f, "%.0f", f)
        slider(c, "Micro Threshold", K.MICRO, 0f, 10f, 1f, 2f, "%.0f", f)
        slider(c, "Acceleration", K.ACCEL, 0f, 0.2f, 0.01f, 0.04f, "%.2f", f)
        slider(c, "Accel Offset", K.ACCEL_OFF, 0f, 10f, 0.25f, 3f, "%.2f", f)
        slider(c, "Accel Cap", K.ACCEL_CAP, 1f, 3f, 0.05f, 1.4f, "%.2f", f)
        slider(c, "Ref DPI", K.REF_DPI, 400f, 3200f, 50f, 800f, "%.0f", f)
        slider(c, "Cur DPI", K.CUR_DPI, 400f, 3200f, 50f, 800f, "%.0f", f)
        slider(c, "Tremor Deadzone", K.TREMOR_DZ, 0f, 10f, 0.5f, 1f, "%.1f", f)
        slider(c, "V-Damping Factor", K.VDAMP_F, 0.3f, 1f, 0.05f, 1f, "%.2f", f)

        val g = { _: Boolean -> onTuningChanged() }
        text(c, "BỘ LỌC", 13f, ACC, true, 14)
        switchRow(c, "Motion Stabilization", K.F_MOTION, true, g)
        switchRow(c, "Anti Overshoot", K.F_OVERSHOOT, false, g)
        switchRow(c, "Quick Start", K.F_QUICK, true, g)
        switchRow(c, "Smooth Transition", K.F_SMOOTH, true, g)
        switchRow(c, "Vertical Damping", K.F_VDAMP, false, g)
        switchRow(c, "Tremor Gate", K.F_TREMOR, false, g)
        switchRow(c, "Direction Assist", K.F_DIRASSIST, false, g)

        button(c, "Áp dụng vào tốc độ hệ thống (từ DPI + đường cong)") {
            val s = Tuning.load(this).systemSpeed()
            Prefs.setFloat(this, K.SPEED_VAL, s.toFloat())
            speedSl.set(s.toFloat())
            applySpeed(s)
            toast("Đã đặt tốc độ hệ thống = $s")
        }
        text(c, "Bộ lọc (EMA, cửa sổ vận tốc, tremor, damping…) áp dụng cho chuột trong khung test của app; phần gain + DPI được quy đổi thành tốc độ con trỏ hệ thống. Android không cho app thường chỉnh từng sự kiện chuột của ứng dụng khác.", 11f, DIM, false, 6)
        onTuningChanged()
    }

    private fun buildSystemCard(col: LinearLayout) {
        val c = card(col, "TIỆN ÍCH HỆ THỐNG (có hiệu lực ngoài app)")
        switchRow(c, "Hiện vị trí con trỏ / tọa độ (Pointer location)", K.POINTER_LOC, false) {
            toggleSystem("system", "pointer_location", it)
        }
        switchRow(c, "Hiện điểm chạm (Show touches)", K.SHOW_TOUCH, false) {
            toggleSystem("system", "show_touches", it)
        }
        switchRow(c, "Con trỏ chuột to (Large pointer icon)", K.BIG_POINTER, false) {
            toggleSystem("secure", "accessibility_large_pointer_icon", it)
        }
    }

    private fun toggleSystem(table: String, key: String, on: Boolean) {
        Thread {
            val ok = Sys.putInt(this, table, key, if (on) 1 else 0)
            ui.post { if (!ok) toast("Cần quyền Shizuku hoặc 'Ghi cài đặt hệ thống' (nhấn nút cấp quyền)") }
        }.start()
    }

    private fun buildNotesCard(col: LinearLayout) {
        val c = card(col, "GHI CHÚ")
        text(
            c,
            "• Shizuku mất khi khởi động lại máy: mở Shizuku và Start lại (Android 11+ dùng Wireless debugging).\n" +
            "• Đã cấp WRITE_SECURE_SETTINGS / Ghi cài đặt thì tốc độ chuột vẫn ghi được kể cả khi Shizuku tắt.\n" +
            "• Xiaomi/Oppo/Vivo/Samsung: bật Tự khởi động, bỏ tối ưu pin, khóa app ở màn hình đa nhiệm.\n" +
            "• Cách khác cấp quyền không cần Shizuku (qua máy tính):\n" +
            "  adb shell pm grant com.hezpor.mousetool android.permission.WRITE_SECURE_SETTINGS",
            12f, DIM, false, 6
        )
    }

    // ---------------- permission logic ----------------

    private fun ensureService() {
        if (!Prefs.getBool(this, K.SERVICE_ON, false)) {
            Prefs.setBool(this, K.SERVICE_ON, true)
            svcSwitch.isChecked = true
        }
    }

    private fun grantAll() {
        if (!ShizukuHelper.granted()) {
            toast("Hãy cấp quyền Shizuku trước (nút 1)")
            return
        }
        val p = packageName
        Thread {
            val cmds = listOf(
                "pm grant $p android.permission.WRITE_SECURE_SETTINGS",
                "pm grant $p android.permission.POST_NOTIFICATIONS",
                "appops set $p WRITE_SETTINGS allow",
                "appops set $p SYSTEM_ALERT_WINDOW allow",
                "appops set $p RUN_IN_BACKGROUND allow",
                "appops set $p RUN_ANY_IN_BACKGROUND allow",
                "cmd deviceidle whitelist +$p"
            )
            val out = ShizukuHelper.exec(cmds.joinToString("; "))
            ui.post {
                toast(if (out == null) "Không chạy được lệnh Shizuku" else "Đã gửi lệnh cấp quyền")
                refreshStatus()
            }
        }.start()
    }

    private fun setStatus(key: String, label: String, ok: Boolean, detail: String) {
        val tv = statusViews[key] ?: return
        tv.text = "● $label: $detail"
        tv.setTextColor(if (ok) OK else BAD)
    }

    private fun refreshStatus() {
        val sAvail = ShizukuHelper.available()
        val sGrant = ShizukuHelper.granted()
        setStatus(
            "shizuku", "Shizuku", sGrant,
            if (sGrant) "đã cấp quyền" else if (sAvail) "đang chạy, chưa cấp quyền" else "chưa chạy"
        )
        val ov = Settings.canDrawOverlays(this)
        setStatus("overlay", "Lớp phủ", ov, if (ov) "đã bật" else "chưa cấp")
        val ws = Settings.System.canWrite(this)
        setStatus("write", "Ghi cài đặt hệ thống", ws, if (ws) "đã cấp" else "chưa cấp (có thể dùng Shizuku)")
        val sec = checkSelfPermission("android.permission.WRITE_SECURE_SETTINGS") == PackageManager.PERMISSION_GRANTED
        setStatus("secure", "WRITE_SECURE_SETTINGS", sec, if (sec) "đã cấp" else "chưa cấp")
        val nt = Build.VERSION.SDK_INT < 33 ||
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
        setStatus("notif", "Thông báo", nt, if (nt) "đã cấp" else "chưa cấp")
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        val bt = pm.isIgnoringBatteryOptimizations(packageName)
        setStatus("battery", "Bỏ tối ưu pin", bt, if (bt) "đã bỏ" else "chưa")
        setStatus("service", "Dịch vụ nền", LiveState.serviceRunning, if (LiveState.serviceRunning) "đang chạy" else "đang tắt")
    }
}
