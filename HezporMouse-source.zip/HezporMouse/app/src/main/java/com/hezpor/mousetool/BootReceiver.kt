package com.hezpor.mousetool

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        try {
            if (Prefs.getBool(context, K.BOOT_ON, true) && Prefs.getBool(context, K.SERVICE_ON, false)) {
                MouseService.start(context)
            }
        } catch (e: Throwable) { }
    }
}
