package com.hezpor.mousetool

import android.content.Context
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.provider.Settings
import rikka.shizuku.Shizuku
import java.util.concurrent.TimeUnit
import kotlin.math.ln
import kotlin.math.roundToInt

object K {
    const val SERVICE_ON = "service_on"
    const val BOOT_ON = "boot_on"
    const val WAKE_ON = "wake_on"
    const val SOUND_ON = "sound_on"
    const val HUD_ON = "hud_on"
    const val SYS_HZ_ON = "sys_hz_on"
    const val SPEED_LOCK = "speed_lock"
    const val SPEED_VAL = "speed_val"
    const val POINTER_LOC = "pointer_loc"
    const val SHOW_TOUCH = "show_touch"
    const val BIG_POINTER = "big_pointer"

    const val EMA = "t_ema"
    const val VELWIN = "t_velwin"
    const val MICRO = "t_micro"
    const val ACCEL = "t_accel"
    const val ACCEL_OFF = "t_accel_off"
    const val ACCEL_CAP = "t_accel_cap"
    const val REF_DPI = "t_ref_dpi"
    const val CUR_DPI = "t_cur_dpi"
    const val TREMOR_DZ = "t_tremor_dz"
    const val VDAMP_F = "t_vdamp_f"

    const val F_MOTION = "f_motion"
    const val F_OVERSHOOT = "f_overshoot"
    const val F_QUICK = "f_quick"
    const val F_SMOOTH = "f_smooth"
    const val F_VDAMP = "f_vdamp"
    const val F_TREMOR = "f_tremor"
    const val F_DIRASSIST = "f_dirassist"
}

object Prefs {
    fun sp(c: Context): SharedPreferences =
        c.applicationContext.getSharedPreferences("hezpor_cfg", Context.MODE_PRIVATE)

    fun getBool(c: Context, k: String, d: Boolean = false): Boolean = sp(c).getBoolean(k, d)
    fun setBool(c: Context, k: String, v: Boolean) { sp(c).edit().putBoolean(k, v).apply() }
    fun getFloat(c: Context, k: String, d: Float = 0f): Float = sp(c).getFloat(k, d)
    fun setFloat(c: Context, k: String, v: Float) { sp(c).edit().putFloat(k, v).apply() }
}

/** Trạng thái chia sẻ giữa Service và Activity (cùng process). */
object LiveState {
    @Volatile var serviceRunning = false
    @Volatile var sysHz = 0
    @Volatile var sysHzTime = 0L
    @Volatile var sysDev = ""
    @Volatile var monitorRunning = false
}

object ShizukuHelper {
    fun available(): Boolean = try { Shizuku.pingBinder() } catch (e: Throwable) { false }

    fun granted(): Boolean = try {
        available() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (e: Throwable) { false }

    fun request(code: Int) {
        try { Shizuku.requestPermission(code) } catch (e: Throwable) { }
    }

    private fun newProcess(cmd: Array<String>): Process? {
        return try {
            val m = Shizuku::class.java.getDeclaredMethod(
                "newProcess",
                Array<String>::class.java, Array<String>::class.java, String::class.java
            )
            m.isAccessible = true
            m.invoke(null, cmd, null, null) as Process
        } catch (e: Throwable) {
            null
        }
    }

    /** Chạy lệnh shell (quyền shell qua Shizuku). Trả về output hoặc null nếu không chạy được. */
    fun exec(cmd: String, timeoutSec: Long = 10): String? {
        if (!granted()) return null
        val p = newProcess(arrayOf("sh", "-c", "($cmd) 2>&1")) ?: return null
        return try {
            val out = p.inputStream.bufferedReader().readText()
            p.waitFor(timeoutSec, TimeUnit.SECONDS)
            out
        } catch (e: Throwable) {
            null
        } finally {
            try { p.destroy() } catch (e: Throwable) { }
        }
    }

    fun stream(cmd: String): Process? {
        if (!granted()) return null
        return newProcess(arrayOf("sh", "-c", cmd))
    }
}

object Sys {
    fun getPointerSpeed(c: Context): Int = try {
        Settings.System.getInt(c.contentResolver, "pointer_speed", 0)
    } catch (e: Throwable) { 0 }

    fun getInt(c: Context, table: String, key: String): Int = try {
        when (table) {
            "secure" -> Settings.Secure.getInt(c.contentResolver, key, 0)
            else -> Settings.System.getInt(c.contentResolver, key, 0)
        }
    } catch (e: Throwable) { 0 }

    /** Ghi setting. Ưu tiên quyền của app, nếu không có thì dùng Shizuku (shell). */
    fun putInt(c: Context, table: String, key: String, v: Int): Boolean {
        try {
            if (table == "system" && Settings.System.canWrite(c)) {
                if (Settings.System.putInt(c.contentResolver, key, v)) return true
            }
            if (table == "secure" &&
                c.checkSelfPermission("android.permission.WRITE_SECURE_SETTINGS") == PackageManager.PERMISSION_GRANTED
            ) {
                if (Settings.Secure.putInt(c.contentResolver, key, v)) return true
            }
        } catch (e: Throwable) { }
        if (ShizukuHelper.granted()) {
            ShizukuHelper.exec("settings put $table $key $v")
            return getInt(c, table, key) == v
        }
        return false
    }

    fun setPointerSpeed(c: Context, v: Int): Boolean =
        putInt(c, "system", "pointer_speed", v.coerceIn(-7, 7))
}

data class Tuning(
    val emaMs: Float, val velWin: Int, val micro: Float,
    val accel: Float, val accelOff: Float, val accelCap: Float,
    val refDpi: Float, val curDpi: Float,
    val motionStab: Boolean, val antiOvershoot: Boolean, val quickStart: Boolean,
    val smoothTrans: Boolean, val vDamp: Boolean, val tremor: Boolean, val dirAssist: Boolean,
    val tremorDz: Float, val vDampFactor: Float
) {
    fun gain(v: Float): Float = minOf(accelCap, 1f + accel * maxOf(0f, v - accelOff))

    fun dpiRatio(): Float = if (curDpi <= 0f) 1f else refDpi / curDpi

    /** Android: scale = 2^(speed/4)  =>  speed = 4*log2(mult). */
    fun systemSpeed(): Int {
        val mult = dpiRatio() * gain(20f)
        val s = 4.0 * ln(mult.toDouble()) / ln(2.0)
        return s.roundToInt().coerceIn(-7, 7)
    }

    companion object {
        fun load(c: Context) = Tuning(
            Prefs.getFloat(c, K.EMA, 2f),
            Prefs.getFloat(c, K.VELWIN, 4f).roundToInt(),
            Prefs.getFloat(c, K.MICRO, 2f),
            Prefs.getFloat(c, K.ACCEL, 0.04f),
            Prefs.getFloat(c, K.ACCEL_OFF, 3f),
            Prefs.getFloat(c, K.ACCEL_CAP, 1.4f),
            Prefs.getFloat(c, K.REF_DPI, 800f),
            Prefs.getFloat(c, K.CUR_DPI, 800f),
            Prefs.getBool(c, K.F_MOTION, true),
            Prefs.getBool(c, K.F_OVERSHOOT, false),
            Prefs.getBool(c, K.F_QUICK, true),
            Prefs.getBool(c, K.F_SMOOTH, true),
            Prefs.getBool(c, K.F_VDAMP, false),
            Prefs.getBool(c, K.F_TREMOR, false),
            Prefs.getBool(c, K.F_DIRASSIST, false),
            Prefs.getFloat(c, K.TREMOR_DZ, 1f),
            Prefs.getFloat(c, K.VDAMP_F, 1f)
        )
    }
}
