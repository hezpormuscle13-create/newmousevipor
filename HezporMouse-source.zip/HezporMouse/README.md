# Hezpor Mouse
App Android: đo Hz chuột (trong app + toàn hệ thống qua Shizuku), chỉnh/khóa tốc độ con trỏ,
HUD Hz nổi, dịch vụ nền, video nền có âm thanh.

Build: đẩy lên GitHub (nhánh main) -> tab Actions -> "Build APK" -> tải ở Releases hoặc Artifacts.
